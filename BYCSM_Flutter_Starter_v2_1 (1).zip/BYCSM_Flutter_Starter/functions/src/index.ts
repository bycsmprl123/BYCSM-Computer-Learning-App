import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { onCall, HttpsError } from 'firebase-functions/v2/https';
initializeApp();
const db = getFirestore();

// Grades on trusted server; student app cannot read the answer key or write scores.
export const submitMcqExam = onCall({ maxInstances: 10 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Please login first.');
  const examId = String(request.data?.examId ?? '');
  const answers = request.data?.answers;
  if (!examId || !Array.isArray(answers)) throw new HttpsError('invalid-argument', 'Exam ID and answers are required.');
  const examSnap = await db.collection('exams').doc(examId).get();
  if (!examSnap.exists || examSnap.data()?.active !== true) throw new HttpsError('not-found', 'Exam is unavailable.');
  const questions = examSnap.data()?.questions;
  const keySnap = await db.collection('examAnswerKeys').doc(examId).get();
  if (!keySnap.exists || !Array.isArray(questions) || !Array.isArray(keySnap.data()?.correctIndexes)) throw new HttpsError('failed-precondition', 'Exam setup is incomplete.');
  const key: number[] = keySnap.data()!.correctIndexes;
  if (answers.length !== questions.length || key.length !== questions.length) throw new HttpsError('invalid-argument', 'Answer count does not match exam.');
  if (answers.some((a: unknown) => !Number.isInteger(a) || Number(a) < -1 || Number(a) > 3)) throw new HttpsError('invalid-argument', 'One or more answer choices are invalid.');
  const score = answers.reduce((total: number, answer: unknown, index: number) => total + (Number(answer) === key[index] ? 1 : 0), 0);
  const total = key.length;
  const percentage = total === 0 ? 0 : Math.round((score / total) * 10000) / 100;
  const profile = await db.collection('students').doc(request.auth!.uid).get();
  const result = { uid: request.auth!.uid, studentName: profile.data()?.fullName ?? 'Student', examId, examTitle: examSnap.data()?.title ?? '', courseTitle: examSnap.data()?.courseTitle ?? '', score, total, percentage, submittedAt: FieldValue.serverTimestamp() };
  const attemptId = `${examId}_${request.auth!.uid}`;
  const attemptRef = db.collection('examAttempts').doc(attemptId);
  await db.runTransaction(async (tx) => {
    const existing = await tx.get(attemptRef);
    if (existing.exists) throw new HttpsError('already-exists', 'You have already submitted this exam.');
    const resultRef = db.collection('examResults').doc();
    tx.create(resultRef, result);
    tx.create(attemptRef, { uid: request.auth!.uid, examId, resultId: resultRef.id, submittedAt: FieldValue.serverTimestamp() });
  });
  return { score, total, percentage };
});
