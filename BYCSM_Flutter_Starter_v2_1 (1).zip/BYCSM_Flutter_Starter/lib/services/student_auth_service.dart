import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class StudentAccount {
  const StudentAccount({
    required this.uid,
    required this.studentId,
    required this.fullName,
    this.isAdmin = false,
  });

  final String uid;
  final String studentId;
  final String fullName;
  final bool isAdmin;
}

class StudentIdCollision implements Exception {
  const StudentIdCollision();
}

/// Student ID + password login backed by Firebase Email/Password Auth.
/// The synthetic email is an internal credential; students only use their ID.
class StudentAuthService {
  StudentAuthService({FirebaseAuth? auth, FirebaseFirestore? db})
      : _auth = auth ?? FirebaseAuth.instance,
        _db = db ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;
  static const _alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  final Random _random = Random.secure();

  String _makeStudentId() {
    final year = DateTime.now().year.toString().substring(2);
    final suffix = List.generate(6, (_) => _alphabet[_random.nextInt(_alphabet.length)]).join();
    return 'BYCSM-$year-$suffix';
  }

  String _internalEmail(String studentId) => '${studentId.toLowerCase()}@students.bycsmlogin.invalid';

  Future<StudentAccount> register({
    required String fullName,
    required String password,
    String mobile = '',
  }) async {
    final cleanName = fullName.trim();
    if (cleanName.length < 2) throw ArgumentError('Please enter the student name.');
    if (password.length < 6) throw ArgumentError('Password must be at least 6 characters.');

    // Random ID collisions are extremely unlikely, but Firestore transaction
    // checks the index so a duplicate can never be silently issued.
    for (var attempt = 0; attempt < 5; attempt++) {
      final studentId = _makeStudentId();
      User? newUser;
      try {
        final credential = await _auth.createUserWithEmailAndPassword(
          email: _internalEmail(studentId),
          password: password,
        );
        newUser = credential.user;
        if (newUser == null) throw StateError('Firebase did not return a user.');

        final uid = newUser.uid;
        final idRef = _db.collection('studentIds').doc(studentId);
        final profileRef = _db.collection('students').doc(uid);
        await _db.runTransaction((tx) async {
          final existing = await tx.get(idRef);
          if (existing.exists) throw const StudentIdCollision();
          tx.set(idRef, {
            'uid': uid,
            'createdAt': FieldValue.serverTimestamp(),
          });
          tx.set(profileRef, {
            'uid': uid,
            'studentId': studentId,
            'fullName': cleanName,
            'mobile': mobile.trim(),
            'status': 'active',
            'createdAt': FieldValue.serverTimestamp(),
          });
        });
        return StudentAccount(uid: uid, studentId: studentId, fullName: cleanName);
      } on StudentIdCollision {
        await newUser?.delete();
        continue;
      } catch (_) {
        // Avoid leaving an Auth account without a profile if the write failed.
        try {
          await newUser?.delete();
        } catch (_) {
          // Preserve the original error; manual cleanup may be needed if offline.
        }
        rethrow;
      }
    }
    throw StateError('Could not issue a unique Student ID. Please try again.');
  }

  Future<StudentAccount> login({required String studentId, required String password}) async {
    final normalizedId = studentId.trim().toUpperCase();
    if (!normalizedId.startsWith('BYCSM-')) {
      throw ArgumentError('Enter your Student ID (example: BYCSM-26-ABC234).');
    }
    final credential = await _auth.signInWithEmailAndPassword(
      email: _internalEmail(normalizedId),
      password: password,
    );
    final user = credential.user;
    if (user == null) throw StateError('Login failed. Please try again.');
    return _loadAccount(user.uid);
  }

  Future<StudentAccount> currentAccount() async {
    final user = _auth.currentUser;
    if (user == null) throw StateError('No signed-in student.');
    return _loadAccount(user.uid);
  }

  Future<StudentAccount> _loadAccount(String uid) async {
    final profile = await _db.collection('students').doc(uid).get();
    if (!profile.exists) {
      await _auth.signOut();
      throw StateError('Student profile not found. Contact the centre administrator.');
    }
    final data = profile.data()!;
    if (data['status'] != 'active') {
      await _auth.signOut();
      throw StateError('This student account is inactive. Contact the centre.');
    }
    final adminDoc = await _db.collection('adminUsers').doc(uid).get();
    return StudentAccount(
      uid: uid,
      studentId: (data['studentId'] ?? '').toString(),
      fullName: (data['fullName'] ?? 'Student').toString(),
      isAdmin: adminDoc.exists && adminDoc.data()?['role'] == 'admin',
    );
  }

  Future<void> changePassword({required String currentPassword, required String newPassword}) async {
    final user = _auth.currentUser;
    if (user == null || user.email == null) throw StateError('Please login again before changing your password.');
    if (newPassword.length < 6) throw ArgumentError('New password must be at least 6 characters.');
    if (newPassword == currentPassword) throw ArgumentError('Choose a different password.');
    final credential = EmailAuthProvider.credential(email: user.email!, password: currentPassword);
    await user.reauthenticateWithCredential(credential);
    await user.updatePassword(newPassword);
  }

  /// Student IDs use a non-deliverable synthetic email, so automated Firebase
  /// email-reset links cannot reach students. Recovery must be admin-assisted
  /// until a verified recovery email/phone is added to registration.
  Future<void> signOut() => _auth.signOut();
  User? get currentUser => _auth.currentUser;
}
