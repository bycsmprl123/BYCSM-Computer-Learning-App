# BYCSM Computer Learning Android App — Starter v0.4

## Implemented in this package
- Flutter Material starter UI and official BYCSM logo
- Student signup (name, optional mobile, password + confirm)
- Firebase Email/Password Auth wrapper using a private synthetic email
- Automatic Student ID issuance (`BYCSM-YY-XXXXXX`), with a Firestore uniqueness transaction
- Student ID/password login and session restore
- Student profile/status check
- Admin tab restricted by an `adminUsers/{uid}` role record
- Course list and Learning Center placeholder screens
- Firestore + Storage security rules and Firebase CLI config
- Android scaffold bootstrap scripts for Windows PowerShell and macOS/Linux

## Not finished / not verified
This is source code, not an APK. No live Firebase project is configured, and Flutter/Dart SDKs are not available in this work environment, so the app could not be compiled or device-tested. Live classes, recorded video playback/upload UI, exam engine, notes/PDF downloads, certificate generation, and admin CRUD screens are still future work.

## Build and connect
1. Install Flutter SDK and Android Studio.
2. Extract this ZIP. From the project folder, create Android project files:
   - Windows: run `scripts\bootstrap_android.ps1` in PowerShell.
   - macOS/Linux: run `bash scripts/bootstrap_android.sh`.
3. Configure Firebase using `docs/FIREBASE_SETUP.md`. Android package target is `org.bycsmission.bycsml`.
4. After FlutterFire config, set `firebaseConfigured = true` in `lib/firebase_config.dart`.
5. Run:
   ```bash
   flutter pub get
   flutter run
   flutter build apk --debug
   ```

## Progress tracker
See `docs/PROGRESS.md` for current decisions and the next development step.


### v0.6 Admin Panel
Admin accounts (configured in Firestore `adminUsers/{uid}` with `role: admin`) can access Course Management to add/edit/delete course records and Student Management to browse student profiles. Course fields include title, description, level, duration, fee, syllabus and active status.

### v0.7 live catalog
Admin course records in Firestore `courses` collection now feed the student catalog. Student list filters `active == true`. Each document may contain `title`, `subtitle`, `level`, `duration`, `fee`, `syllabus` (array of strings), `active`, `updatedAt`, `createdAt`. Only signed-in users can read; Admin writes are enforced by Firestore rules.

## v0.8 Live Classes
- Open Learning > Live Classes to see scheduled sessions.
- Verified admins can open Admin > Live class management, add/edit/delete schedules.
- Schedule fields: title, course, date/time (`YYYY-MM-DD HH:MM`), meeting URL.
- Students tap a class to launch the meeting URL in the browser/meeting app.
- Requires Firebase configured and Firestore rules deployed; admin identity must be present in `adminUsers/{uid}` with role `admin`.

## v0.9 Recorded Lessons
- Learning Center > Recorded Videos opens the student video library.
- Admin Console > Recorded video management can add, edit, and delete lesson entries.
- Lesson fields: title, courseTitle, description, videoUrl (HTTPS/HTTP), lessonOrder, active.
- Student taps a lesson to open the video URL externally and may toggle completed status.
- Student progress documents use `videoProgress/{uid_videoId}` and store UID, video ID, completion, and update timestamp.
- This release supports links only (YouTube or direct URL), not binary file upload. Firebase Storage upload UI remains a future task.
- Deploy updated Firestore rules from `firebase/firestore.rules` before using lesson progress.


### v1.0 MCQ exams (new source)
Exam management is available from Admin Console and MCQ Exams from Learning Center. Admin creates exams and 4-option questions. Answer keys are kept in admin-only Firestore documents; scoring is performed by a Firebase callable Cloud Function. Students have a timer and one submission per exam.

To deploy the grading backend after Firebase setup:
1. `cd functions && npm install && npm run build`
2. Return to project root and run `firebase deploy --only firestore:rules,functions:submitMcqExam`
3. Test using an authenticated student and an admin account.

The code has not been Flutter-compiled or deployed in this environment.

### v1.1 Notes / PDF Library
Admin can manage PDF note metadata and HTTPS links in the Notes / PDF Management page. Students can browse notes, optionally filtered by course, and open the PDF link externally. Direct file upload is not yet supported; configure Firebase Storage and implement upload in a later release.

### v1.2 Certificates
Student Learning Center > Certificates shows certificates issued to the signed-in account. Admin Console > Certificate management issues a certificate using the student's Firebase UID, full name and course name. The certificate record gets a BYCSM serial and timestamp. Students/Admin can use the print icon to print or save a landscape PDF certificate. Admin must be registered in `adminUsers`; certificates are admin-write and student-owner/admin-readable.

This is a source-code feature, not a compiled or device-tested APK. Admin currently needs the student's Firebase UID; course completion is not automatically verified.

## v1.3 Enrollment & Progress
Admin Console now includes Enrollment & Progress. Enroll students by their Firebase UID into active courses and maintain status, progress, lesson count, attendance, exam average and notes. Students see their own enrollment progress from Learning Center. Deploy updated firestore rules before using.


## v1.4 Attendance
- Admins can create attendance sessions and mark students Present/Absent/Late by Firebase UID.
- Students can view their attendance records and percentage.
- Attendance data is stored in `attendanceSessions` and `attendanceRecords`.
- Deploy updated Firestore rules before testing.


## v1.5 — Digital Student ID Card
- Student home now includes Digital Student ID entry.
- Card displays student name, unique Student ID, BYCSM centre label, issue date, and QR payload.
- QR code contains `BYCSM-STUDENT|<StudentID>` only.
- Print/Save PDF uses a PDF QR barcode.
- Online QR verification is not deployed; this is an offline identification QR.


## v1.6 Student Profile
Student profile page supports editing full name, mobile, address, guardian name, and HTTPS photo URL. Student ID, account status, and role remain read-only. Firebase Storage photo upload is deferred.


## v1.7 Password security
Open Home or Learning > Change Password. Students re-enter their current password, then provide a new password and confirmation. Firebase Authentication re-authenticates and updates it. Forgot password is admin-assisted at present because student accounts use synthetic login email addresses; do not promise email reset until a verified recovery email/phone is collected and wired.

### v1.8 Notices
Student: Home or Learning → Notifications to see published announcements and mark them read.
Admin: Admin Console → Notice management → New notice. Set category, optional course label and Published visibility. Edit/delete from each notice menu.
This release adds an in-app inbox only; FCM push notification delivery is not enabled.


## v1.9 — Settings & Help Center
- Settings and Help page added to Home and Learning tabs.
- About BYCSM, app version, centre address, call and WhatsApp links.
- FAQ dialog and privacy/security information.
- Change Password shortcut.
- Support/contact links require a phone handler and use the centre contact configured in the app.
- Not compiled or device-tested; Firebase setup/deployment still required.


## v2.0 Integration & Build Preparation
- Version bumped to `2.0.0+20`.
- Added guarded Android debug build scripts for Windows and Linux/macOS. Scripts stop if Flutter, Android scaffold, or real Firebase configuration is missing.
- Added `docs/BUILD_AND_QA_v2_0.md` with setup, deployment, build and QA checklist.
- APK is not built in this environment; Flutter SDK and Firebase configuration are still required.

## v2.1 Android build options
See `docs/ANDROID_APK_QUICKSTART_v2_1.md` for local Windows steps and GitHub Actions cloud-build steps. Workflow: `.github/workflows/android-apk-build.yml`.
