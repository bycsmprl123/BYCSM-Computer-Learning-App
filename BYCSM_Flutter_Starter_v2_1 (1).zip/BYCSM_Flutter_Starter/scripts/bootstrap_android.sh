#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter is not installed or not on PATH. Install Flutter SDK first." >&2
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [ -d "$ROOT/android" ]; then
  echo "android/ already exists; refusing to overwrite." >&2
  exit 1
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

flutter create --platforms=android --org org.bycsmission --project-name bycsml "$TMP/bycsml"
cp -R "$TMP/bycsml/android" "$ROOT/android"
cd "$ROOT"
flutter pub get

echo "Android scaffold created. Next: flutterfire configure, then follow docs/FIREBASE_SETUP.md."
