$ErrorActionPreference = 'Stop'
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  Write-Error 'Flutter is not installed or not on PATH. Install Flutter SDK first.'
}
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
if (Test-Path (Join-Path $root 'android')) { Write-Error 'android/ already exists; refusing to overwrite.' }
$tmp = Join-Path $env:TEMP ('bycsm_android_' + [guid]::NewGuid().ToString())
New-Item -ItemType Directory -Path $tmp | Out-Null
try {
  flutter create --platforms=android --org org.bycsmission --project-name bycsml (Join-Path $tmp 'bycsml')
  Copy-Item -Recurse (Join-Path $tmp 'bycsml/android') (Join-Path $root 'android')
  Set-Location $root
  flutter pub get
  Write-Host 'Android scaffold created. Next: flutterfire configure, then follow docs/FIREBASE_SETUP.md.'
} finally {
  Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
}
