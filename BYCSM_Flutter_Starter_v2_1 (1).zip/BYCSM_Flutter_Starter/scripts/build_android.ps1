$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) { throw 'Flutter SDK not found. Install Flutter and add it to PATH.' }
if (-not (Test-Path 'android')) { throw 'Android scaffold missing. Run scripts\bootstrap_android.ps1 first.' }
if ((Select-String -Path 'lib\firebase_options.dart' -Pattern 'CONFIGURE_FIREBASE_API_KEY|bycsm-configure-me' -Quiet) { throw 'Firebase placeholders detected. Run flutterfire configure first.' }
if ((Select-String -Path 'lib\firebase_config.dart' -Pattern 'firebaseConfigured = false' -Quiet) { throw 'Firebase is disabled. Configure Firebase before build.' }
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
Write-Host "Debug APK: $Root\build\app\outputs\flutter-apk\app-debug.apk"
