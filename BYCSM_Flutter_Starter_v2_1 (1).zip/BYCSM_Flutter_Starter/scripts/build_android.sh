#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK not found. Install Flutter and add it to PATH." >&2; exit 1
fi
if [ ! -d android ]; then
  echo "Android scaffold missing. Run scripts/bootstrap_android.sh first." >&2; exit 1
fi
if grep -q "CONFIGURE_FIREBASE_API_KEY\|bycsm-configure-me" lib/firebase_options.dart; then
  echo "Firebase placeholders detected. Run flutterfire configure and review lib/firebase_options.dart first." >&2; exit 1
fi
if grep -q "firebaseConfigured = false" lib/firebase_config.dart; then
  echo "Firebase is still disabled. Set firebaseConfigured=true only after configuring Firebase." >&2; exit 1
fi
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
printf '\nDebug APK should be at: %s\n' "$ROOT/build/app/outputs/flutter-apk/app-debug.apk"
