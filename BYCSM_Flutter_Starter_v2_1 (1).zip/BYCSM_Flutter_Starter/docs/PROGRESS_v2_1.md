# Progress v2.1 — Android build setup

- Added GitHub Actions workflow for Flutter Android debug APK builds.
- Workflow checks Firebase configuration, runs `flutter pub get`, `flutter analyze`, `flutter test`, builds APK, and uploads it as a 14-day artifact.
- Added a concise Windows and cloud-build guide.
- Existing Windows/Linux bootstrap/build scripts remain available.

**Not verified in this environment:** Flutter SDK/Android SDK are unavailable, Firebase project is not connected, and no APK was produced. Workflow file is source-added but not executed on GitHub.
