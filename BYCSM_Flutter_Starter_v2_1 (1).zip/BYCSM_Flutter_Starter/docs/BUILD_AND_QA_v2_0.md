# BYCSM v2.0 Integration & Android Build Preparation

## Build status
This package contains Flutter source and build scripts. An APK has **not** been built or verified here because Flutter/Dart SDK and a configured Firebase project are not available in this environment.

## Before building
1. Install Flutter SDK and Android Studio (Android SDK + platform tools).
2. Open a terminal in this project folder.
3. Run the Android scaffold script once:
   - Windows PowerShell: `scripts\\bootstrap_android.ps1`
   - Linux/macOS: `bash scripts/bootstrap_android.sh`
4. Create/configure a Firebase project. Enable Authentication (Email/Password) and Firestore.
5. Install FlutterFire CLI (`dart pub global activate flutterfire_cli`) and ensure it is on PATH.
6. Run `flutterfire configure` from project root; select Android and this Firebase project. Review the generated `lib/firebase_options.dart`.
7. Change `firebaseConfigured` to `true` in `lib/firebase_config.dart` only after real Firebase options are configured.
8. Deploy rules/indexes: `firebase deploy --only firestore:rules,firestore:indexes,storage` (Firebase CLI login/project selection required).
9. Configure an Admin UID in Firestore `adminUsers/{uid}` with `role: "admin"` using a trusted console process. Do not let the client self-assign Admin.
10. Build and run QA.

## Automated build script
- Linux/macOS: `bash scripts/build_android.sh`
- Windows PowerShell: `scripts\\build_android.ps1`

The script verifies that Flutter exists, Android scaffold exists, Firebase placeholder values are removed, Firebase is enabled, then runs `flutter pub get`, `flutter analyze`, `flutter test`, and `flutter build apk --debug`.

## Manual QA checklist
- [ ] Registration: create student, ID uniqueness, reject invalid inputs
- [ ] Login: Student ID/password, wrong credentials, session persistence, logout
- [ ] Student-only access; verify admin routes are inaccessible to students
- [ ] Admin role verified by Firestore rules; no client role escalation
- [ ] Course catalog: active courses visible, inactive hidden
- [ ] Live class: schedule and meeting URL open
- [ ] Recorded lesson: link opens; progress can be saved
- [ ] Exam: timer, one submission, scoring and result history; answer keys not readable by student
- [ ] Notes: course filters and PDF links
- [ ] Certificate: student only sees own certificates; PDF print preview
- [ ] Enrollment/progress: only correct student sees own progress
- [ ] Attendance: owner sees own records; admin marks present/absent/late
- [ ] Student ID: QR payload contains identifier only, not private details
- [ ] Profile: editable fields update; role/ID/status protected
- [ ] Password change: re-authentication; password never stored in Firestore
- [ ] Notices: published filtering and read/unread state
- [ ] Settings/help: links, support contact and FAQ
- [ ] Test Firestore and Storage rules with Firebase Emulator or a non-production test project
- [ ] Check Android back button, small screen layouts, network failures, loading/error states

## Release notes / limitations
- v2.0 is integration/build preparation, not a release APK.
- Firebase credentials/project setup, rules deployment, SDK compilation, emulator/device testing and Play Store signing are external setup steps.
- Link-based videos and PDFs are supported in current source; binary upload and push notifications are not fully implemented/deployed.
- Release signing must be configured separately; never commit keystore/passwords to this repository.
