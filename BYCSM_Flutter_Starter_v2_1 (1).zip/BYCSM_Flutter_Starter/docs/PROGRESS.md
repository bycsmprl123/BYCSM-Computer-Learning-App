# BYCSM App project progress

## Latest package: v0.4 (2026-11-22)

### Decisions
- Android-first Flutter app.
- Student username is a centre-issued ID, not an email address.
- Firebase Email/Password Auth uses an internal synthetic email; student ID is shown to the user and is the login input.
- ID format: `BYCSM-YY-XXXXXX` (random uppercase letters/numbers excluding confusing characters).
- Firestore `students/{uid}` holds profile; `studentIds/{studentId}` is a collision-checked index.
- Admin role is assigned manually in `adminUsers/{uid}`; app clients cannot create admin records.
- No passwords stored in Firestore.

### Completed in source
- Registration/login UI wired to the Firebase auth service (configuration is still required).
- Student ID generation, collision check, profile creation, login, session restore, inactive profile check.
- Student ID shown after successful signup.
- Admin UI access check.
- Firestore/Storage starter rules and Firebase CLI config.
- Android scaffold bootstrap scripts.

### Not completed
- Firebase project connection and rule deployment.
- Android build/APK and device test.
- Dynamic course catalog/admin CRUD.
- Live class scheduling/meeting launch.
- Recorded video upload and playback.
- MCQ exam UI, trusted scoring, result records.
- Notes/PDF library and downloads.
- Certificate templates/generation.

### Next step
Add Firestore-backed course catalogue with admin add/edit/delete and student read-only listing, then move live class/video content metadata into Firestore. Firebase credentials/project access and an Android test environment are needed for integration verification.


## v0.6 — Admin Panel
- Added Firebase-backed Admin Course Management page: create, edit, delete courses with title, description, level, duration, fee, syllabus and active status.
- Added Student Management list (read-only student profiles).
- Admin routes are shown only to accounts whose Firebase adminUsers/{uid} document has role=admin.
- Flutter SDK/build validation is still pending in an environment with Flutter installed.
- Next: connect Admin-managed course documents to student catalog, then course enrollment and lesson uploads.

## v0.7 — Firebase live course catalog
- Student Course tab now listens to `courses` collection and displays only `active == true` documents.
- Course cards show description, level, duration, and fee when provided.
- Course detail page uses the syllabus stored in Firestore; otherwise uses built-in sample outline.
- Admin course management already writes `courses`; this release connects those records to the student view.
- Offline/unconfigured Firebase uses the built-in sample course catalog.
- No APK built or device testing performed (Flutter SDK unavailable in this workspace).

## v0.8 — Live class schedule and join links
- Added Firestore-backed LiveClassesPage for students and admins.
- Admins can schedule, edit, and delete classes with title, course, start date/time, and meeting URL.
- Students see active scheduled classes and can open meeting links externally.
- Added url_launcher dependency and bumped app version to 0.8.0+8.
- Firestore rules already permit signed-in read and admin write for liveClasses.
- Build/device verification remains pending because Flutter SDK and Firebase credentials are not configured in this environment.


## v0.9 — Recorded video lesson library
- Added student recorded video library backed by Firestore `recordedVideos`.
- Added admin lesson create/edit/delete UI for title, course, description, video URL and lesson order.
- Video links open externally (YouTube or direct HTTPS URL).
- Students can mark lessons complete; progress is stored in `videoProgress` per signed-in UID.
- Added Firestore rules for student-owned progress and admin video management.
- Direct file uploads are not implemented yet; this build manages links. Firebase Storage setup is needed for upload feature.
- Flutter build and device testing remain pending.


## v1.0 — MCQ Exam Module (source added)
- Admin exam creation: title, course, duration, 4-option questions, correct-answer selection.
- Student exam list and course-filtered list, countdown, answer selection, submit.
- Correct answer keys stored in admin-only `examAnswerKeys` documents.
- Server grading callable (`functions/src/index.ts`) returns score and percentage; results stored in `examResults`.
- One submission per student/exam enforced by `examAttempts` transaction.
- Admin can view result list and delete exams.
- Not yet compiled or deployed; Flutter SDK and Firebase project access are required.

## v1.1 Notes / PDF Library
- Added student notes library page with course filtering and Firestore live list.
- Added admin create/edit/delete note metadata: title, course, chapter, description, PDF HTTPS URL.
- Notes open external PDF links in the device browser/PDF viewer.
- Added Notes management entry to Admin Console and Notes entry from course detail.
- Firestore rules already restrict notes write access to admins; authenticated users can read.
- Direct PDF file upload is NOT included yet; the admin currently saves a shareable HTTPS URL. Firebase Storage upload and download handling remain a next step.
- This code was edited in the project archive but Flutter/Dart compilation was not run because SDK is unavailable in this environment.

## v1.2 — Certificate module (source implementation)
- Added student certificate wallet backed by Firestore `certificates` collection.
- Added Admin certificate issuance form (Firebase student UID, name, course) and issuance metadata.
- Added certificate ID generation, issued date display, and Print/Save as PDF action.
- Certificates collection security remains admin-write and owner/admin-read.
- Limitations: admin must know/paste student's Firebase UID; issuance is manual and no course-completion validation is implemented yet. Flutter compilation/device testing not performed in this environment.


## v1.3 — Enrollment and Student Progress (source implementation)
- Admin Enrollment & Progress page: enroll student by Firebase UID into active course; checks the student profile exists.
- Enrollment records include student/course identity, enrollment timestamp, status, progress percent, lessons, attendance, exam average, and admin note.
- Admin can update progress/status and learning metrics.
- Student My Progress page reads only the signed-in student's enrollment records.
- Firestore rules: owner/admin read; admin-only writes.
- Metrics are admin-maintained placeholders at this stage; automatic lesson attendance/exam aggregation is not wired yet.
- Firebase deployment and Flutter compile/device tests remain pending.


## v1.4 - Attendance module added (source)
- Admin attendance sessions
- Manual attendance marking by student Firebase UID
- Present / Absent / Late status
- Student history and percentage summary
- Firestore rules for admin writes and self/admin reads
- Flutter compilation/device test still required


### v1.5 Digital Student ID Card
- Added Student ID card screen from Home.
- QR contains Student ID payload; avoids embedding UID or private profile data.
- PDF print/save action included.
- Online verification endpoint remains unimplemented.


## v1.6
- Student profile view/edit screen added.
- Editable fields: full name, mobile, address, guardian name, photo URL.
- Student ID/status/role are not editable by student.
- Firestore rules updated to permit those profile fields.
- Direct photo upload and compile/device testing remain pending.


## v1.7 — Password Security (source implementation)
- Added change-password page from Home/Learning sections.
- Re-authenticates with current password before Firebase Auth update.
- Validates minimum length and confirmation; blocks reusing same password.
- Password changes are handled by Firebase Authentication; no plain-text password storage.
- Forgot-password recovery is explicitly admin-assisted for now because Student ID accounts use synthetic, non-deliverable emails. Verified recovery contact collection and reset flow are future work.
- Flutter compilation/device testing and Firebase setup remain pending.

## v1.8 — Notices & in-app notification centre (2026-11-22)
- Added `lib/notices.dart`: student notice inbox, categories (Announcement/Live Class/Exam/Notes/Certificate), course label, published/unpublished visibility, read receipts, admin create/edit/delete.
- Wired Notifications into student Home and Learning tabs and Admin Console.
- Added Firestore rules for `notices` (admin write, students read published) and `noticeReads` (student-owned read receipts).
- This is an in-app notice centre only. Push notifications/FCM are not configured yet.
- Flutter compile/device test still required; Firebase rules need deploy after review.


## v1.9 — Settings & Help Center
- Settings and Help page added to Home and Learning tabs.
- About BYCSM, app version, centre address, call and WhatsApp links.
- FAQ dialog and privacy/security information.
- Change Password shortcut.
- Support/contact links require a phone handler and use the centre contact configured in the app.
- Not compiled or device-tested; Firebase setup/deployment still required.
