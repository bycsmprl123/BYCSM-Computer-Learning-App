# BYCSM Firebase setup — v0.4 auth integration

## What this version implements
- Student registration with name, optional mobile, password and confirm password.
- Automatically issues a Student ID such as `BYCSM-26-ABC234`.
- Student ID + password login; students do not need to provide an email address.
- Firebase Auth uses a private synthetic email as its internal credential.
- Firestore stores student profile and a Student ID index in a transaction.
- Admin navigation is locked unless the UID is present in `adminUsers`.

## External setup required
You need a Firebase account/project. This package is not connected to a live project yet.

1. Create a Firebase project.
2. Add an Android app with package ID **`org.bycsmission.bycsml`**.
3. Enable **Authentication → Sign-in method → Email/Password**. No email verification is used; the internal email is synthetic.
4. Create **Firestore Database**.
5. Install Flutter and Android Studio. Install FlutterFire CLI:
   ```bash
   dart pub global activate flutterfire_cli
   ```
6. From the app folder, run:
   ```bash
   flutterfire configure
   ```
   Choose the Firebase project and Android app. This generates `lib/firebase_options.dart`; it replaces the placeholder file in this package.
7. Set `firebaseConfigured` to `true` in `lib/firebase_config.dart`.
8. Publish Firestore and Storage rules (Firebase CLI recommended):
   ```bash
   firebase login
   firebase use --add
   firebase deploy --only firestore:rules,storage
   ```
   The included `firebase.json` points to the rules files. Storage must be enabled in the Firebase Console.
9. Run `flutter pub get`, then `flutter run`.

## Add centre owner as admin
1. Register an owner account in the app.
2. In Firebase Console → Authentication, copy the owner's UID.
3. In Firestore, create collection `adminUsers`, document ID = UID, with fields:
   - `role` (string): `admin`
   - `displayName` (string): owner name (optional)
4. Sign out, then log in again. Admin navigation will be unlocked.

Do not make `adminUsers` writable from the app. Create admin entries only in Firebase Console or a future trusted backend.

## Security and limitations
- Starter rules are a first pass, not a production security audit. Test in Firebase Emulator/Rules Playground before using real student records.
- Student IDs use secure random characters and Firestore collision checks.
- Passwords are not stored in Firestore.
- If a profile transaction fails, the app attempts to delete the newly created Auth user; an offline failure may leave an orphan that needs console cleanup.
- Password reset is not implemented. Since students have no email, a future reset flow must be designed for centre-admin assistance without exposing passwords.
- Exam results cannot be created by students in the included rules; a trusted scoring backend is needed.
- Live classes, videos, exam questions/scoring, notes, certificates, and admin management/upload UI remain placeholders.
